`timescale 1ns / 1ps
module bin_to_bcd_11bits (
    input      [10:0] bin,        // 0-2047
    output     [3:0]  thousands,  // only ever 0-2
    output     [3:0]  hundreds,
    output     [3:0]  tens,
    output     [3:0]  ones
);
    reg [26:0] sr;   // [10:0]=binary field, [14:11]=ones, [18:15]=tens,
                      // [22:19]=hundreds, [26:23]=thousands
    integer i;

    always @* begin
        sr = 27'd0;
        sr[10:0] = bin;
        for (i = 0; i < 11; i = i + 1) begin
            if (sr[14:11] > 4) sr[14:11] = sr[14:11] + 3;
            if (sr[18:15] > 4) sr[18:15] = sr[18:15] + 3;
            if (sr[22:19] > 4) sr[22:19] = sr[22:19] + 3;
            // thousands digit never exceeds 2 for inputs <= 2047,
            // so its correction step is omitted
            sr = sr << 1;
        end
    end

    assign thousands = sr[26:23];
    assign hundreds  = sr[22:19];
    assign tens      = sr[18:15];
    assign ones      = sr[14:11];
    
endmodule