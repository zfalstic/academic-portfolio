`timescale 1ns / 1ps
module up_counter (
    input wire clk, reset, en, reset_pulse,
    output reg [15:0] count,
    output wire done
);

    always @(posedge clk or posedge reset) begin
        if (reset) count <= 0;
        else if (en & count != {16{1'b1}}) count <= count + 1;
        else if (reset_pulse) count <= 0;
    end

    assign done = (count == {16{1'b1}});
    
endmodule
