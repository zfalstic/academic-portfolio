`timescale 1ns / 1ps
module led_top (
    input wire clk, reset, en,
    input wire [9:0] count,
    output wire [15:0] led
);

    wire pulse;
    led_pulse_controller pulse_controller (
        .count(count),
        .pulse(pulse)
    );
    
    wire filtered_pulse = pulse & en;

    wire [15:0] unfiltered_led;
    pulse_left_shift left_shift (
        .clk(clk),
        .pulse(filtered_pulse),
        .reset(reset),
        .en(en),
        .out(unfiltered_led)
    );
    
    assign led = unfiltered_led & {16{en}};
    
endmodule
