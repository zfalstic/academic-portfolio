`timescale 1ns / 1ps
module led_pulse_controller (
    input wire [9:0] count,
    output reg pulse
);

    always @(*) begin
        case ({count})
            10'd222: pulse = 1;
            10'd207: pulse = 1;
            10'd193: pulse = 1;
            10'd178: pulse = 1;
            10'd163: pulse = 1;
            10'd148: pulse = 1;
            10'd133: pulse = 1;
            10'd119: pulse = 1;
            10'd104: pulse = 1;
            10'd89:  pulse = 1;
            10'd74:  pulse = 1;
            10'd59:  pulse = 1;
            10'd44:  pulse = 1;
            10'd30:  pulse = 1;
            10'd15:  pulse = 1;
            10'd0:   pulse = 1;
            default: pulse = 0;
        endcase
    end

endmodule
