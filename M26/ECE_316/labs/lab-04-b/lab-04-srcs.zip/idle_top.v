`timescale 1ns / 1ps
module idle_top (
    input wire clk, reset,
    output wire [27:0] sseg
);

    assign sseg[6:0]    = 7'b1000000;
    assign sseg[13:7]   = 7'b1000000;
    assign sseg[20:14]  = 7'b1000000;
    assign sseg[27:21]  = 7'b1000000;

endmodule
