`timescale 1ns / 1ps
module datapath_top #(
    parameter integer CLKDIV_BIT = 20,
    parameter [9:0] T_LEVEL = 10'd237, //  5 seconds
    parameter [9:0] T_GAME = 10'd714   // 15 seconds
) (
    input wire clk, reset,
    input wire btnU, btnD, btnL, btnR, btnC,
    input wire user_submit,
    output wire [15:0] led,
    output wire [6:0] seg,
    output wire [3:0] an
);

    wire fsm_clk;
    clkdiv_20 #(.BIT(CLKDIV_BIT)) clk_20 (
        .clk        (clk),
        .reset      (reset),
        .clk_out    (fsm_clk)
    );
    
    wire [1:0] state;
    wire [3:0] transition, pulse;
    fsm_controller fsm (
        .clk(fsm_clk),
        .reset(reset),
        .transition(transition),
        .state(state),
        .pulse(pulse)
    );
    
    wire [3:0] en;
    assign en[0] = (state == 2'd0);
    assign en[1] = (state == 2'd1);
    assign en[2] = (state == 2'd2);
    assign en[3] = (state == 2'd3);
    
    wire pulse_c;
    rising_edge_detector c_ed (
        .clk(fsm_clk),
        .reset(reset),
        .signal(btnC),
        .outedge(pulse_c)
    );
    
    wire pulse_user_submit;
    rising_edge_detector user_submit_ed (
        .clk(fsm_clk),
        .reset(reset),
        .signal(user_submit),
        .outedge(pulse_user_submit)
    );
    
    wire time_done;
    wire [9:0] count;
    down_counter timer (
        .clk(fsm_clk),
        .reset(reset),
        .load(pulse[1] | pulse[2]),
        .load_val(pulse[1] ? T_LEVEL : T_GAME),
        .count(count),
        .done(time_done)
    );
    
    led_top leds (
        .clk(fsm_clk),
        .reset(reset),
        .en(en[1]),
        .count(count),
        .led(led)
    );
    
    assign transition[0] = pulse_c && en[0]; // IDLE -> LEVEL on button press
    assign transition[1] = time_done && en[1]; // LEVEL -> GAME after 5  seconds
    assign transition[2] = pulse_user_submit && en[2]; // GAME -> SCORE after 15 seconds
    assign transition[3] = pulse_c && en[3]; // SCORE -> IDLE on button press
    
    wire [27:0] mux_in [0:3];
    
    idle_top idle (
        .clk(),
        .reset(reset),
        .sseg(mux_in[0])
    );
    
    assign mux_in[1][27:14] = 0;
    level_top level (
        .clk(clk),
        .reset(reset),
        .load(pulse[1]),
        .comp_sol(mux_in[1][13:0])
    );
    
    game_top game (
        .clk(fsm_clk),
        .reset(reset),
        .en(en[2]),
        .reset_pulse(transition[3]),
        .btn_u(btnU),
        .btn_d(btnD),
        .btn_l(btnL),
        .btn_r(btnR),
        .pulse_c(pulse_c),
        .user_sol(mux_in[2][13:0]),
        .position(mux_in[2][27:14])
    );
    
    wire [15:0] user_time;
    up_counter user_timer (
        .clk(fsm_clk),
        .reset(reset),
        .en(en[2]),
        .reset_pulse(transition[3]),
        .count(user_time),
        .done()
    );
    
    score_top score (
        .clk(),
        .user_time(user_time),
        .comp_sol(mux_in[1][13:0]),
        .user_sol(mux_in[2][13:0]),
        .reset(reset),
        .sseg(mux_in[3])
    );
    
    wire [27:0] seg_in;
    mux_28bit_4to1 seg_mux (
        .in0(mux_in[0]),
        .in1(mux_in[1]),
        .in2(mux_in[2]),
        .in3(mux_in[3]),
        .sel(state),
        .out(seg_in)
    );
    
    seven_segment_top sseg (
        .clk(clk),
        .reset(reset),
        .in0(seg_in[6:0]),
        .in1(seg_in[13:7]),
        .in2(seg_in[20:14]),
        .in3(seg_in[27:21]),
        .an(an),
        .sseg(seg)
    );

endmodule
