`timescale 1ns / 1ps
module clkdiv_20 #(parameter integer BIT = 20) (
    input wire clk,
    input wire reset,
    output wire clk_out
);
    reg [BIT:0] COUNT; // 47.68 Hz
    
    assign clk_out = COUNT[BIT];
    
    always @(posedge clk) begin
        if (reset) COUNT <= 0;
        else COUNT <= COUNT + 1;
    end
endmodule