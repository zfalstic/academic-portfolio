`timescale 1ns / 1ps
module fsm_controller (
    input clk, reset,
    input wire [3:0] transition,
    output reg [1:0] state,
    output wire [3:0] pulse
);

    reg [1:0] next_state;
    
    assign pulse[0] = (state != 2'b00) && (next_state == 2'b00);
    assign pulse[1] = (state != 2'b01) && (next_state == 2'b01);
    assign pulse[2] = (state != 2'b10) && (next_state == 2'b10);
    assign pulse[3] = (state != 2'b11) && (next_state == 2'b11);
    
    always @(*) begin
        case ({state, transition})
            6'b00_0001: next_state = 2'b01;
            6'b01_0010: next_state = 2'b10;
            6'b10_0100: next_state = 2'b11;
            6'b11_1000: next_state = 2'b00;
            default: next_state = state;
        endcase
    end
    
    always @(posedge clk or posedge reset) begin
        if (reset) state <= 0;
        else state <= next_state;
    end
    
endmodule
