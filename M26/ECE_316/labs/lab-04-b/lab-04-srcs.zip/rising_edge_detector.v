`timescale 1ns / 1ps
module rising_edge_detector (
    input wire clk,
    input wire signal,
    input wire reset,
    output reg outedge
);
    reg [1:0] state, next_state;
    
    // Combinational logic: next state + output.
    always @(*) begin
        // Hint: use a case statement on the current state.
        case ({state, signal})
            3'b000: begin next_state = 2'b00; outedge = 1'b0; end
            3'b001: begin next_state = 2'b01; outedge = 1'b0; end
            3'b010: begin next_state = 2'b00; outedge = 1'b1; end
            3'b011: begin next_state = 2'b10; outedge = 1'b1; end
            3'b100: begin next_state = 2'b00; outedge = 1'b0; end
            3'b101: begin next_state = 2'b10; outedge = 1'b0; end
            //3'b110: begin next_state = 2'b00; outedge = 1'b0; end
            //3'b111: begin next_state = 2'b00; outedge = 1'b0; end
            default: begin next_state = 2'b00; outedge = 1'b0; end
        endcase
    end
    
    // Sequential logic on the slow clock with asynchronous reset.
    always @(posedge clk or posedge reset) begin
        // Hint: don't forget about the reset signal, which can be handled with an if-statement.
        if (reset) state <= 2'b00;
        else state <= next_state;
    end
endmodule