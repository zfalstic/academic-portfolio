`timescale 1ns / 1ps
module mux_28bit_4to1 (
    input wire [27:0] in0, in1, in2, in3,
    input wire [1:0] sel,
    output reg [27:0] out
);

    always @(*) begin
        case ({sel})
            2'b00: out = in0;
            2'b01: out = in1;
            2'b10: out = in2;
            2'b11: out = in3;
            default: out = 28'd0;
        endcase
    end

endmodule
