`timescale 1ns / 1ps
module game_controller (
    input wire clk, reset, en, reset_pulse,
    input wire up, down, left, right, middle,
    output wire [13:0] position, // position of user
    output reg [13:0] user_sol  // solution inputted by user
);

    reg [3:0] state , next_state;
    
    assign position = 14'b1 << (state[3] * 7 + state[2:0]);
    
    // state switching logic
    always @(*) begin
        case({state, up, down, left, right}) // 8 bits
            8'b0000_0000: next_state = 4'b0000;
            8'b0000_1000: next_state = 4'b0000;
            8'b0000_0100: next_state = 4'b0101;
            8'b0000_0010: next_state = 4'b1000;
            8'b0000_0001: next_state = 4'b0000;
            8'b0001_0000: next_state = 4'b0001;
            8'b0001_1000: next_state = 4'b0000;
            8'b0001_0100: next_state = 4'b0110;
            8'b0001_0010: next_state = 4'b0101;
            8'b0001_0001: next_state = 4'b0001;
            8'b0010_0000: next_state = 4'b0010;
            8'b0010_1000: next_state = 4'b0110;
            8'b0010_0100: next_state = 4'b0011;
            8'b0010_0010: next_state = 4'b0100;
            8'b0010_0001: next_state = 4'b0010;
            8'b0011_0000: next_state = 4'b0011;
            8'b0011_1000: next_state = 4'b0100;
            8'b0011_0100: next_state = 4'b0011;
            8'b0011_0010: next_state = 4'b1011;
            8'b0011_0001: next_state = 4'b0011;
            8'b0100_0000: next_state = 4'b0100;
            8'b0100_1000: next_state = 4'b0110;
            8'b0100_0100: next_state = 4'b0011;
            8'b0100_0010: next_state = 4'b1010;
            8'b0100_0001: next_state = 4'b0010;
            8'b0101_0000: next_state = 4'b0101;
            8'b0101_1000: next_state = 4'b0000;
            8'b0101_0100: next_state = 4'b0110;
            8'b0101_0010: next_state = 4'b1001;
            8'b0101_0001: next_state = 4'b0001;
            8'b0110_0000: next_state = 4'b0110;
            8'b0110_1000: next_state = 4'b0101;
            8'b0110_0100: next_state = 4'b0100;
            8'b0110_0010: next_state = 4'b1110;
            8'b0110_0001: next_state = 4'b0110;
            8'b1000_0000: next_state = 4'b1000;
            8'b1000_1000: next_state = 4'b1000;
            8'b1000_0100: next_state = 4'b1101;
            8'b1000_0010: next_state = 4'b1000;
            8'b1000_0001: next_state = 4'b0000;
            8'b1001_0000: next_state = 4'b1001;
            8'b1001_1000: next_state = 4'b1000;
            8'b1001_0100: next_state = 4'b1110;
            8'b1001_0010: next_state = 4'b1101;
            8'b1001_0001: next_state = 4'b0101;
            8'b1010_0000: next_state = 4'b1010;
            8'b1010_1000: next_state = 4'b1110;
            8'b1010_0100: next_state = 4'b1011;
            8'b1010_0010: next_state = 4'b1100;
            8'b1010_0001: next_state = 4'b0100;
            8'b1011_0000: next_state = 4'b1011;
            8'b1011_1000: next_state = 4'b1100;
            8'b1011_0100: next_state = 4'b1011;
            8'b1011_0010: next_state = 4'b1011;
            8'b1011_0001: next_state = 4'b0011;
            8'b1100_0000: next_state = 4'b1100;
            8'b1100_1000: next_state = 4'b1110;
            8'b1100_0100: next_state = 4'b1011;
            8'b1100_0010: next_state = 4'b1100;
            8'b1100_0001: next_state = 4'b1010;
            8'b1101_0000: next_state = 4'b1101;
            8'b1101_1000: next_state = 4'b1000;
            8'b1101_0100: next_state = 4'b1110;
            8'b1101_0010: next_state = 4'b1101;
            8'b1101_0001: next_state = 4'b1001;
            8'b1110_0000: next_state = 4'b1110;
            8'b1110_1000: next_state = 4'b1101;
            8'b1110_0100: next_state = 4'b1100;
            8'b1110_0010: next_state = 4'b1110;
            8'b1110_0001: next_state = 4'b0110;
            default: next_state = state;
        endcase
    end
    
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state <= 4'b0000;
            user_sol <= 14'b0000000_0000000;
        end else if (en) begin
            state <= next_state;
            if (middle) user_sol <= user_sol ^ position;
        end else if (reset_pulse) begin
            state <= 4'b0000;
            user_sol <= 14'b0000000_0000000;
        end
    end
    
endmodule
