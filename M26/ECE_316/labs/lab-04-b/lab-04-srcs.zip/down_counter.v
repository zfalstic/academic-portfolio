`timescale 1ns / 1ps
module down_counter (
    input  wire       clk, reset, load,
    input  wire [9:0] load_val,
    output reg  [9:0] count,
    output wire       done
);

    always @(posedge clk or posedge reset) begin
        if (reset)           count <= 0;
        else if (load)       count <= load_val;
        else if (count != 0) count <= count - 1;
    end

    assign done = (count == 0);
    
endmodule