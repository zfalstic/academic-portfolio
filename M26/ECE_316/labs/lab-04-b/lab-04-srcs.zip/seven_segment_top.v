`timescale 1ns / 1ps

module seven_segment_top #(parameter integer DISP_BIT = 17) (
    input  wire         clk, reset,
    input  wire [6:0]   in0, in1, in2, in3,
    output wire [3:0]   an,
    output wire [6:0]   sseg
);
    wire clk_disp;

    // DISP_BIT selects the refresh-divider width. Default 17 matches hardware
    // (~380 Hz scan from 100 MHz); simulation overrides it to a small value so
    // the 4-digit scan completes well within the 1,000,000 ns budget.
    clkdiv_disp #(.BIT(DISP_BIT)) disp_clk (.clk(clk), .reset(reset), .clk_out(clk_disp));
    
    time_mux_state_machine fsm (
        .clk(clk_disp), .reset(reset),
        .in0(~in0), .in1(~in1), .in2(~in2), .in3(~in3),
        .an(an), .sseg(sseg)
    );
    
endmodule
