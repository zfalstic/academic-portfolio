`timescale 1ns / 1ps
module time_mux_state_machine (
    input  wire         clk, reset,
    input  wire [6:0]   in0, in1, in2, in3,
    output reg  [3:0]   an,
    output reg  [6:0]   sseg
);
    reg [1:0] state, next_state;
    
    // State Transition Combinational
    always @(*) begin
        case (state)
            2'd0:       next_state = 2'd1;
            2'd1:       next_state = 2'd2;
            2'd2:       next_state = 2'd3;
            2'd3:       next_state = 2'd0;
            default:    next_state = 2'd0;
        endcase
    end
    
    // Anode Output Combinational
    always @(*) begin
        case (state)
            2'd0:       an = 4'b1110;
            2'd1:       an = 4'b1101;
            2'd2:       an = 4'b1011;
            2'd3:       an = 4'b0111;
            default:    an = 4'b1111;
        endcase
    end
    
    // SSEG Output Combinational
    always @(*) begin
        case (state)
            2'd0:       sseg = in0;
            2'd1:       sseg = in1;
            2'd2:       sseg = in2;
            2'd3:       sseg = in3;
            default:    sseg = 7'b1111111;
        endcase
    end
    
    always @(posedge clk or posedge reset) begin
        if (reset) state <= 2'd0;
        else state <= next_state;
    end
endmodule
