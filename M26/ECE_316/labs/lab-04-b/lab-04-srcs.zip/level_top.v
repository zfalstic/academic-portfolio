`timescale 1ns / 1ps
module level_top (
    input wire clk,
    input wire reset, load,
    output wire [13:0] comp_sol
);

    wire [2:0] random;
    lfsr_3bit lfsr(.clk(clk), .reset(reset), .out(random));
    
    reg [2:0] selector;
    always @(posedge clk or posedge reset) begin
        if (reset) selector <= 3'b001;
        else if (load) selector <= random;
    end
    
    wire [13:0] levels [0:7];
    assign levels[0] = 14'b0000000_0000000; // 000 is never chosen
    assign levels[1] = 14'b0100011_1111000;
    assign levels[2] = 14'b1010100_0100111;
    assign levels[3] = 14'b1110010_1001001;
    assign levels[4] = 14'b0101001_0101101;
    assign levels[5] = 14'b1000100_1111010;
    assign levels[6] = 14'b0111010_0100110;
    assign levels[7] = 14'b1001010_0101011;
    
    mux_14bit_8to1 mux (
        .in0(levels[0]), 
        .in1(levels[1]), 
        .in2(levels[2]), 
        .in3(levels[3]), 
        .in4(levels[4]), 
        .in5(levels[5]), 
        .in6(levels[6]), 
        .in7(levels[7]), 
        .sel(selector), 
        .out(comp_sol)
    );
    
endmodule
