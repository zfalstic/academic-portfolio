`timescale 1ns / 1ps
module game_top (
    input wire clk, reset, en, reset_pulse,
    input wire btn_u, btn_d, btn_l, btn_r,
    input wire pulse_c,
    output wire [13:0] position,
    output wire [13:0] user_sol
);
    
    wire pulse_u, pulse_d, pulse_l, pulse_r;
    rising_edge_detector u_ed(.clk(clk), .reset(reset), .signal(btn_u), .outedge(pulse_u));
    rising_edge_detector d_ed(.clk(clk), .reset(reset), .signal(btn_d), .outedge(pulse_d));
    rising_edge_detector l_ed(.clk(clk), .reset(reset), .signal(btn_l), .outedge(pulse_l));
    rising_edge_detector r_ed(.clk(clk), .reset(reset), .signal(btn_r), .outedge(pulse_r));
    
    game_controller game(
        .clk (clk),
        .reset(reset),
        .en(en),
        .reset_pulse(reset_pulse),
        .up(pulse_u),
        .down(pulse_d),
        .left(pulse_l),
        .right(pulse_r),
        .middle(pulse_c),
        .position(position),
        .user_sol(user_sol)
    );
    
endmodule
