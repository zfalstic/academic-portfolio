`timescale 1ns / 1ps
module lfsr_3bit (
    input wire clk, reset,
    output reg [2:0] out
);
    wire feedback = out[0] ^ out[1];
    
    always @(posedge clk or posedge reset) begin
        if (reset) out <= 3'b111;
        else out <= {feedback, out[2:1]};
    end
endmodule
