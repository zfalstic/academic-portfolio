`timescale 1ns / 1ps
module mux_28bit_2to1 (
    input wire [27:0] in0, in1,
    input wire sel,
    output reg [27:0] out
);

    always @(*) begin
        case({sel})
            1'b0: out = in0;
            1'b1: out = in1;
            default: out = 28'd0;
        endcase
    end
    
endmodule
