`timescale 1ns / 1ps
module clkdiv_disp #(parameter integer BIT = 17) (
    input wire clk,
    input wire reset,
    output wire clk_out
);
    reg [BIT:0] COUNT; //17 by default; override BIT to speed up simulation

    assign clk_out = COUNT[BIT];
    
    always @(posedge clk) begin
        if (reset) COUNT <= 0;
        else COUNT <= COUNT + 1;
    end
endmodule