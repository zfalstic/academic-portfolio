`timescale 1ns / 1ps
module score_top (
    input wire clk, reset,
    input wire [15:0] user_time,
    input wire [13:0] user_sol, comp_sol,
    output wire [27:0] sseg
);
    wire match = user_sol == comp_sol;
    wire [10:0] user_time_secs = user_time / 48;
    
    wire [3:0] thousands, hundreds, tens, ones;
    bin_to_bcd_11bits bin2bcd (
        .bin(user_time_secs),
        .thousands(thousands),
        .hundreds(hundreds),
        .tens(tens),
        .ones(ones)
    );
    
    wire [6:0] thou_sseg, hund_sseg, tens_sseg, ones_sseg;
    bcd_to_sseg thou_bcd2sseg (.bcd(thousands), .seg(thou_sseg));
    bcd_to_sseg hund_bcd2sseg (.bcd(hundreds), .seg(hund_sseg));
    bcd_to_sseg tens_bcd2sseg (.bcd(tens), .seg(tens_sseg));
    bcd_to_sseg ones_bcd2sseg (.bcd(ones), .seg(ones_sseg));
    
    wire [27:0] mux_in [0:1];

    assign mux_in[0][6:0]    = 7'b1100111;
    assign mux_in[0][13:7]   = 7'b1100111;
    assign mux_in[0][20:14]  = 7'b1100111;
    assign mux_in[0][27:21]  = 7'b1100111;
    
    assign mux_in[1][6:0]    = ones_sseg;
    assign mux_in[1][13:7]   = tens_sseg;
    assign mux_in[1][20:14]  = hund_sseg;
    assign mux_in[1][27:21]  = thou_sseg;
    
    mux_28bit_2to1 mux (
        .in0(mux_in[0]),
        .in1(mux_in[1]),
        .sel(match),
        .out(sseg)
    );

endmodule
