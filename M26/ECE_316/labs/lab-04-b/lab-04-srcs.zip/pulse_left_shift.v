`timescale 1ns / 1ps
module pulse_left_shift (
    input wire clk, pulse, reset, en,
    output reg [15:0] out
);

    always @(posedge clk or posedge reset) begin
        if (reset) out <= 16'b11111111_11111111;
        else if (pulse) out <= {out[14:0], 1'b0};
        else if (!en) out <= 16'b11111111_11111111;
    end

endmodule
