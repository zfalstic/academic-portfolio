`timescale 1ns / 1ps
//=============================================================================
// score_top_tb.v  --  self-checking testbench for score_top
//
// Covers the whole SCORE datapath plus its two building blocks directly:
//   * bin_to_bcd_11bits : 11-bit binary -> 4 BCD digits (double-dabble)
//   * bcd_to_sseg       : BCD digit -> active-high 7-segment pattern
//   * score_top         : match ? BCD(user_time/48) on 4 digits : "no-match" word
//
// Everything here is combinational, so the run is a few hundred ns.
//=============================================================================
module score_top_tb;

    integer errors, checks;

    //-------------------------------------------------------------------------
    // Golden reference for the 7-segment encoding (mirrors bcd_to_sseg.v)
    //-------------------------------------------------------------------------
    function [6:0] seg7;
        input [3:0] d;
        begin
            case (d)
                4'd0: seg7 = 7'b0111111;
                4'd1: seg7 = 7'b0000110;
                4'd2: seg7 = 7'b1011011;
                4'd3: seg7 = 7'b1001111;
                4'd4: seg7 = 7'b1100110;
                4'd5: seg7 = 7'b1101101;
                4'd6: seg7 = 7'b1111101;
                4'd7: seg7 = 7'b0000111;
                4'd8: seg7 = 7'b1111111;
                4'd9: seg7 = 7'b1101111;
                default: seg7 = 7'b0000000;
            endcase
        end
    endfunction

    localparam [6:0] NOMATCH = 7'b1100111;   // score_top's "wrong answer" glyph

    task chk_val;
        input [31:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %0h, expected %0h)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%0h)", $time, msg, actual);
        end
    endtask

    //=========================================================================
    // 1) bin_to_bcd_11bits
    //=========================================================================
    reg  [10:0] bin_tv;
    wire [3:0]  b_thou, b_hund, b_tens, b_ones;

    bin_to_bcd_11bits b2b (
        .bin       (bin_tv),
        .thousands (b_thou),
        .hundreds  (b_hund),
        .tens      (b_tens),
        .ones      (b_ones)
    );

    task chk_bcd;
        input [10:0] v;
        begin
            bin_tv = v; #1;
            chk_val(b_thou, (v/1000)%10, "bin_to_bcd thousands");
            chk_val(b_hund, (v/100)%10,  "bin_to_bcd hundreds");
            chk_val(b_tens, (v/10)%10,   "bin_to_bcd tens");
            chk_val(b_ones, v%10,        "bin_to_bcd ones");
        end
    endtask

    //=========================================================================
    // 2) bcd_to_sseg
    //=========================================================================
    reg  [3:0] bcd_tv;
    wire [6:0] seg_tv;

    bcd_to_sseg b2s (.bcd(bcd_tv), .seg(seg_tv));

    task chk_seg;
        input [3:0] d;
        begin
            bcd_tv = d; #1;
            chk_val(seg_tv, seg7(d), "bcd_to_sseg digit");
        end
    endtask

    //=========================================================================
    // 3) score_top
    //=========================================================================
    reg  [15:0] user_time;
    reg  [13:0] user_sol, comp_sol;
    wire [27:0] sseg;

    score_top uut (
        .clk       (1'b0),
        .reset     (1'b0),
        .user_time (user_time),
        .user_sol  (user_sol),
        .comp_sol  (comp_sol),
        .sseg      (sseg)
    );

    // Expected 28-bit word when the solution matches: BCD of user_time/48.
    function [27:0] score_word;
        input [15:0] t;
        reg [10:0] s;
        begin
            s = t / 48;
            score_word = { seg7((s/1000)%10), seg7((s/100)%10),
                           seg7((s/10)%10),   seg7(s%10) };
        end
    endfunction

    task chk_score_match;
        input [15:0] t;
        begin
            user_sol = 14'h1555; comp_sol = 14'h1555;   // equal -> match
            user_time = t; #1;
            chk_val(sseg, score_word(t), "score match: BCD(user_time/48)");
        end
    endtask

    //-------------------------------------------------------------------------
    // Watchdog
    //-------------------------------------------------------------------------
    initial begin
        #10_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    integer i;
    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        bin_tv = 0; bcd_tv = 0; user_time = 0; user_sol = 0; comp_sol = 0;

        $display("\n=== score_top testbench ===");

        $display("\n--- bin_to_bcd_11bits ---");
        chk_bcd(11'd0);    chk_bcd(11'd1);    chk_bcd(11'd9);
        chk_bcd(11'd10);   chk_bcd(11'd42);   chk_bcd(11'd99);
        chk_bcd(11'd100);  chk_bcd(11'd123);  chk_bcd(11'd500);
        chk_bcd(11'd999);  chk_bcd(11'd1000); chk_bcd(11'd1234);
        chk_bcd(11'd2047);

        $display("\n--- bcd_to_sseg ---");
        for (i = 0; i <= 9; i = i + 1) chk_seg(i[3:0]);
        chk_seg(4'd10);   // out-of-range -> blank (0000000)
        chk_seg(4'd15);

        $display("\n--- score_top: match path shows the time in seconds ---");
        chk_score_match(16'd48);     //   1 s  -> 0001
        chk_score_match(16'd0);      //   0 s  -> 0000
        chk_score_match(16'd240);    //   5 s  -> 0005
        chk_score_match(16'd5904);   // 123 s  -> 0123
        chk_score_match(16'd65535);  // 1365 s -> 1365

        $display("\n--- score_top: no-match path shows the wrong-answer word ---");
        user_sol = 14'h0001; comp_sol = 14'h0002; user_time = 16'd5000; #1;
        chk_val(sseg, {NOMATCH, NOMATCH, NOMATCH, NOMATCH},
                "mismatch -> four wrong-answer glyphs");
        chk_val(sseg[6:0], NOMATCH, "mismatch digit0 field");

        // Equal-but-nonzero solutions also count as a match.
        user_sol = 14'h3FFF; comp_sol = 14'h3FFF; user_time = 16'd96; #1;
        chk_val(sseg, score_word(16'd96), "all-ones solution match -> 0002");

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
