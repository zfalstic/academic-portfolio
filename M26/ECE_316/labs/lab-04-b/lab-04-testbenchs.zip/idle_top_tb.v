`timescale 1ns / 1ps
//=============================================================================
// idle_top_tb.v  --  self-checking testbench for idle_top
//
// idle_top is purely combinational: it drives a constant "four dashes" word
// onto the 28-bit sseg bus (each 7-bit field = 7'b1000000 = segment g only).
// clk/reset are unused by the RTL; we still toggle them to prove they have no
// effect.  Runs in well under 1,000,000 ns.
//=============================================================================
module idle_top_tb;

    reg         clk, reset;
    wire [27:0] sseg;

    // Expected: segment g (dash) on all four digits, active-high.
    localparam [6:0]  DASH   = 7'b1000000;
    localparam [27:0] DASHES = {DASH, DASH, DASH, DASH};

    integer errors, checks;

    idle_top uut (
        .clk   (clk),
        .reset (reset),
        .sseg  (sseg)
    );

    // Free-running clock, just to prove the output is clock-independent.
    initial clk = 1'b0;
    always #5 clk = ~clk;

    task chk_val;
        input [27:0]   actual;
        input [27:0]   expected;
        input [8*48:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %07h, expected %07h)",
                         $time, msg, actual, expected);
            end else begin
                $display("[%t]     pass : %0s (%07h)", $time, msg, actual);
            end
        end
    endtask

    // Watchdog
    initial begin
        #10_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;

        $display("\n=== idle_top testbench ===");

        reset = 1'b1;
        #12;
        chk_val(sseg,        DASHES, "sseg is four dashes during reset");
        chk_val(sseg[6:0],   DASH,   "digit0 field is a dash");
        chk_val(sseg[13:7],  DASH,   "digit1 field is a dash");
        chk_val(sseg[20:14], DASH,   "digit2 field is a dash");
        chk_val(sseg[27:21], DASH,   "digit3 field is a dash");

        reset = 1'b0;
        #20;
        chk_val(sseg, DASHES, "sseg unchanged after reset deasserted");

        #33;                        // sample away from a clock edge
        chk_val(sseg, DASHES, "sseg unchanged across clock edges");

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL",
                 checks-errors, checks);
        $finish;
    end

endmodule
