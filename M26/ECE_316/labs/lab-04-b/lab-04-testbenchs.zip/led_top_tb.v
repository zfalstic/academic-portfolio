`timescale 1ns / 1ps
//=============================================================================
// led_top_tb.v  --  self-checking testbench for led_top
//
// led_top drives a 16-LED "shrinking bar" countdown.  A shift register starts
// at 0xFFFF (all lit); each time `count` passes one of 16 preset thresholds the
// pulse controller fires and shifts a 0 in from the LSB, so after k thresholds
// led == (0xFFFF << k).  led is additionally masked by `en`, and the register
// re-arms to 0xFFFF whenever en is low.
//
// count is driven directly here (in the real design it comes from down_counter),
// one threshold per clock.  Run is well under 1 us.
//=============================================================================
module led_top_tb;

    localparam integer CLK_PERIOD = 10;

    reg         clk, reset, en;
    reg  [9:0]  count;
    wire [15:0] led;

    integer errors, checks, k;
    reg [15:0] exp;

    // 16 thresholds in the descending order the real counter visits them.
    integer thr [0:15];

    led_top uut (
        .clk   (clk),
        .reset (reset),
        .en    (en),
        .count (count),
        .led   (led)
    );

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    task chk_val;
        input [15:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %04h, expected %04h)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%04h)", $time, msg, actual);
        end
    endtask

    task reset_dut;
        begin
            @(negedge clk); reset = 1'b1;
            @(posedge clk); #1;
            @(negedge clk); reset = 1'b0; #1;
        end
    endtask

    initial begin
        #20_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        thr[0]=222; thr[1]=207; thr[2]=193; thr[3]=178; thr[4]=163;
        thr[5]=148; thr[6]=133; thr[7]=119; thr[8]=104; thr[9]=89;
        thr[10]=74; thr[11]=59; thr[12]=44; thr[13]=30; thr[14]=15; thr[15]=0;

        en = 1'b1; count = 10'd500; reset = 1'b1;   // 500 is not a threshold

        $display("\n=== led_top testbench ===");

        reset_dut;
        chk_val(led, 16'hFFFF, "reset -> all 16 LEDs lit");

        // A non-threshold count causes no shift.
        @(negedge clk); count = 10'd500;
        @(posedge clk); #1;
        chk_val(led, 16'hFFFF, "non-threshold count -> no shift");

        // Full sweep: each threshold peels one LED off the bottom.
        $display("\n--- sweep the 16 thresholds, bar shrinks by one each ---");
        for (k = 0; k < 16; k = k + 1) begin
            @(negedge clk); count = thr[k][9:0];
            @(posedge clk); #1;
            exp = 16'hFFFF << (k + 1);           // truncates to 16 bits
            chk_val(led, exp, "threshold shifts one 0 in from the LSB");
        end
        chk_val(led, 16'h0000, "after all 16 thresholds the bar is empty");

        // en low blanks the LEDs immediately (combinational mask)...
        reset_dut;
        chk_val(led, 16'hFFFF, "re-armed to full after reset");
        @(negedge clk); count = thr[0][9:0];      // arm a shift
        @(posedge clk); #1;
        chk_val(led, 16'hFFFE, "one shift before disabling");
        @(negedge clk); en = 1'b0; #1;
        chk_val(led, 16'h0000, "en low blanks led output");
        // ...and re-arms the register to 0xFFFF on the next clock.
        @(posedge clk);                           // register reloads 0xFFFF
        @(negedge clk); en = 1'b1; count = 10'd500; #1;
        chk_val(led, 16'hFFFF, "en high again -> bar restored to full");

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
