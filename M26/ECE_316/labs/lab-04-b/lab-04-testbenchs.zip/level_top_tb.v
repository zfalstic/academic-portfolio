`timescale 1ns / 1ps
//=============================================================================
// level_top_tb.v  --  self-checking testbench for level_top
//
// level_top picks one of 7 preset "comp_sol" patterns.  A 3-bit LFSR free-runs
// on clk; on `load` the selector latches the current LFSR value; the 8:1 mux
// then drives comp_sol = levels[selector].  After reset selector = 1, and the
// LFSR (seed 111) never produces 0, so level 0 is never chosen.
//
// Checks are robust to the exact LFSR value: we read the DUT's selector and
// confirm comp_sol == levels[selector], plus the deterministic reset/hold cases.
// Driven off a 10 ns TB clock -> run is under 1 us.
//=============================================================================
module level_top_tb;

    localparam integer CLK_PERIOD = 10;

    reg        clk, reset, load;
    wire [13:0] comp_sol;

    integer errors, checks, i;
    reg [2:0] r0;

    level_top uut (
        .clk      (clk),
        .reset    (reset),
        .load     (load),
        .comp_sol (comp_sol)
    );

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // Golden copy of the level table (mirrors level_top.v).
    function [13:0] level_lut;
        input [2:0] s;
        begin
            case (s)
                3'd0: level_lut = 14'b0000000_0000000;
                3'd1: level_lut = 14'b0100011_1111000;
                3'd2: level_lut = 14'b1010100_0100111;
                3'd3: level_lut = 14'b1110010_1001001;
                3'd4: level_lut = 14'b0101001_0101101;
                3'd5: level_lut = 14'b1000100_1111010;
                3'd6: level_lut = 14'b0111010_0100110;
                3'd7: level_lut = 14'b1001010_0101011;
                default: level_lut = 14'd0;
            endcase
        end
    endfunction

    task chk_val;
        input [31:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %h, expected %h)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%h)", $time, msg, actual);
        end
    endtask

    task chk_true;
        input          cond;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (cond !== 1'b1) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s", $time, msg);
            end else
                $display("[%t]     pass : %0s", $time, msg);
        end
    endtask

    // Latch the LFSR on `load` for exactly one clock, then verify the mux.
    task do_load;
        input [8*40:1] msg;
        begin
            @(negedge clk);
            load = 1'b1;
            r0   = uut.random;          // value that will be latched at the edge
            @(posedge clk); #1;
            @(negedge clk);
            load = 1'b0;
            chk_val(uut.selector, r0,               "selector latched LFSR value");
            chk_true(uut.selector !== 3'd0,         "selector never 0 (level 0 unused)");
            chk_val(comp_sol, level_lut(uut.selector), msg);
        end
    endtask

    initial begin
        #20_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        load = 1'b0; reset = 1'b1;

        $display("\n=== level_top testbench ===");

        repeat (2) @(posedge clk);
        @(negedge clk); reset = 1'b0; #1;
        chk_val(uut.selector, 3'd1,           "reset -> selector == 1");
        chk_val(comp_sol, level_lut(3'd1),    "reset -> comp_sol == levels[1]");

        // selector holds while the LFSR free-runs (no load asserted).
        repeat (4) @(posedge clk); #1;
        chk_val(uut.selector, 3'd1,           "selector holds without load");
        chk_val(comp_sol, level_lut(3'd1),    "comp_sol holds without load");

        // A handful of loads at different LFSR phases.
        do_load("comp_sol == levels[selector] after load #1");
        repeat (2) @(posedge clk);
        do_load("comp_sol == levels[selector] after load #2");
        repeat (3) @(posedge clk);
        do_load("comp_sol == levels[selector] after load #3");

        // LFSR sweeps its full period without ever hitting 0.
        $display("\n--- LFSR never emits 0 over a full period ---");
        for (i = 0; i < 8; i = i + 1) begin
            @(posedge clk); #1;
            chk_true(uut.random !== 3'd0, "LFSR output stays non-zero");
        end

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
