`timescale 1ns / 1ps
//=============================================================================
// seven_segment_top_tb.v  --  self-checking testbench for seven_segment_top
//
// seven_segment_top time-multiplexes 4 active-high digit words onto one shared
// 7-segment bus, driving them active-low: for digit k, an selects the digit and
// sseg = ~inK.  The scan is paced by clkdiv_disp.
//
// clkdiv_disp is 17 bits in hardware (~2.6 ms per refresh), which would blow the
// 1,000,000 ns budget before a single digit changed.  The design was
// parameterized (DISP_BIT) so simulation can shrink that divider; here DISP_BIT=2
// gives a clk_disp edge every 8 clk (80 ns), so several full 4-digit scans fit
// in under 1 us.
//=============================================================================
module seven_segment_top_tb;

    localparam integer CLK_PERIOD = 10;
    localparam integer DISP_BIT   = 2;    // sim-only fast refresh divider

    reg        clk, reset;
    reg  [6:0] in0, in1, in2, in3;
    wire [3:0] an;
    wire [6:0] sseg;

    integer errors, checks, i;
    reg [1:0] exp_state;

    seven_segment_top #(.DISP_BIT(DISP_BIT)) uut (
        .clk   (clk),
        .reset (reset),
        .in0   (in0),
        .in1   (in1),
        .in2   (in2),
        .in3   (in3),
        .an    (an),
        .sseg  (sseg)
    );

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // Expected active-low anode select for each scan phase.
    function [3:0] an_exp;
        input [1:0] s;
        case (s)
            2'd0: an_exp = 4'b1110;
            2'd1: an_exp = 4'b1101;
            2'd2: an_exp = 4'b1011;
            2'd3: an_exp = 4'b0111;
        endcase
    endfunction

    // Expected segment word: the selected digit's input, inverted (active-low).
    function [6:0] seg_exp;
        input [1:0] s;
        case (s)
            2'd0: seg_exp = ~in0;
            2'd1: seg_exp = ~in1;
            2'd2: seg_exp = ~in2;
            2'd3: seg_exp = ~in3;
        endcase
    endfunction

    task chk_val;
        input [31:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %b, expected %b)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%b)", $time, msg, actual);
        end
    endtask

    task chk_phase;
        input [1:0] s;
        begin
            chk_val(uut.fsm.state, s,          "scan phase (fsm state)");
            chk_val(an,            an_exp(s),  "anode select for this digit");
            chk_val(sseg,          seg_exp(s), "segment word is ~inK");
        end
    endtask

    initial begin
        #30_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        // Four distinct 7-bit words so each digit is clearly identifiable.
        in0 = 7'h11; in1 = 7'h22; in2 = 7'h33; in3 = 7'h44;
        reset = 1'b1;

        $display("\n=== seven_segment_top testbench (DISP_BIT=%0d) ===", DISP_BIT);

        // clkdiv_disp has a synchronous reset -> hold reset across a few clks.
        repeat (5) @(posedge clk);
        @(negedge clk); reset = 1'b0; #1;

        chk_val(uut.fsm.state, 2'd0, "after reset scan starts on digit 0");
        chk_phase(2'd0);

        // Two full scans across all four digits.
        exp_state = 2'd0;
        for (i = 0; i < 8; i = i + 1) begin
            @(posedge uut.clk_disp); #1;
            exp_state = exp_state + 2'd1;
            chk_phase(exp_state);
        end

        // Changing the digit words is reflected on the active phase.
        @(negedge clk);
        in0 = 7'h7F; in1 = 7'h00; in2 = 7'h55; in3 = 7'h2A;
        // Re-sync to a known phase and re-check one full scan.
        @(posedge uut.clk_disp); #1;
        exp_state = uut.fsm.state;
        for (i = 0; i < 4; i = i + 1) begin
            chk_phase(exp_state);
            @(posedge uut.clk_disp); #1;
            exp_state = exp_state + 2'd1;
        end

        // Async reset snaps the scanner back to digit 0.
        #3 reset = 1'b1; #1;
        chk_val(uut.fsm.state, 2'd0, "async reset -> scan phase 0");
        chk_val(an,            4'b1110, "async reset -> anode digit 0");
        @(negedge clk); reset = 1'b0;

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
