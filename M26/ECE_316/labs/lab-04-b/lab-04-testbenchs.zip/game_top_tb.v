`timescale 1ns / 1ps
//=============================================================================
// game_top_tb.v  --  self-checking testbench for game_top
//
// game_top = 4 rising-edge detectors (U/D/L/R) + game_controller.  A button
// press produces exactly one cursor move; `pulse_c` (already an edge in the
// real design) toggles the segment under the cursor into user_sol via XOR.
// Moves/toggles only happen while en=1; reset_pulse clears state+user_sol when
// en=0; async reset clears immediately.
//
// Cursor state -> one-hot position: bit = state[3]*7 + state[2:0].
// Driven off a 10 ns TB clock -> run is a couple of us.
//=============================================================================
module game_top_tb;

    localparam integer CLK_PERIOD = 10;
    localparam integer U=0, D=1, L=2, R=3;

    reg         clk, reset, en, reset_pulse;
    reg         btn_u, btn_d, btn_l, btn_r, pulse_c;
    wire [13:0] position, user_sol;

    integer errors, checks;

    game_top uut (
        .clk        (clk),
        .reset      (reset),
        .en         (en),
        .reset_pulse(reset_pulse),
        .btn_u      (btn_u),
        .btn_d      (btn_d),
        .btn_l      (btn_l),
        .btn_r      (btn_r),
        .pulse_c    (pulse_c),
        .position   (position),
        .user_sol   (user_sol)
    );

    wire [3:0] gstate = uut.game.state;   // probe the cursor FSM state

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    task chk_val;
        input [31:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %h, expected %h)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%h)", $time, msg, actual);
        end
    endtask

    // Press a direction long enough for the edge detector to emit one pulse,
    // then release and let it return to idle: nets one cursor move (if en).
    task press;
        input integer which;
        begin
            @(negedge clk);
            case (which)
                U: btn_u = 1'b1;  D: btn_d = 1'b1;
                L: btn_l = 1'b1;  R: btn_r = 1'b1;
            endcase
            repeat (2) @(posedge clk);
            @(negedge clk);
            btn_u = 1'b0; btn_d = 1'b0; btn_l = 1'b0; btn_r = 1'b0;
            repeat (2) @(posedge clk);
            #1;
        end
    endtask

    // Single-cycle center strobe -> one XOR toggle of user_sol.
    task center;
        begin
            @(negedge clk); pulse_c = 1'b1;
            @(posedge clk); #1;
            @(negedge clk); pulse_c = 1'b0; #1;
        end
    endtask

    task pulse_reset;   // one-cycle reset_pulse (only effective while en=0)
        begin
            @(negedge clk); reset_pulse = 1'b1;
            @(posedge clk); #1;
            @(negedge clk); reset_pulse = 1'b0; #1;
        end
    endtask

    initial begin
        #50_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        en = 1'b0; reset_pulse = 1'b0; pulse_c = 1'b0;
        btn_u = 0; btn_d = 0; btn_l = 0; btn_r = 0; reset = 1'b1;

        $display("\n=== game_top testbench ===");

        repeat (3) @(posedge clk);
        @(negedge clk); reset = 1'b0; #1;
        chk_val(gstate,   4'b0000,   "reset -> cursor state 0");
        chk_val(position, 14'h0001,  "reset -> cursor on bit 0");
        chk_val(user_sol, 14'h0000,  "reset -> user_sol cleared");

        // Enable the game and exercise moves + toggles.
        @(negedge clk); en = 1'b1;

        $display("\n--- toggle + cursor movement ---");
        center;
        chk_val(user_sol, 14'h0001, "center toggles bit 0 into user_sol");

        press(L);
        chk_val(gstate,   4'b1000,  "left: 0000 -> 1000");
        chk_val(position, 14'h0080, "cursor one-hot at bit 7");
        center;
        chk_val(user_sol, 14'h0081, "center toggles bit 7");

        press(R);
        chk_val(gstate,   4'b0000,  "right: 1000 -> 0000");
        chk_val(position, 14'h0001, "cursor back at bit 0");
        center;
        chk_val(user_sol, 14'h0080, "XOR clears the previously set bit 0");

        press(D);
        chk_val(gstate,   4'b0101,  "down: 0000 -> 0101");
        chk_val(position, 14'h0020, "cursor one-hot at bit 5");
        press(D);
        chk_val(gstate,   4'b0110,  "down: 0101 -> 0110");
        chk_val(position, 14'h0040, "cursor one-hot at bit 6");
        press(U);
        chk_val(gstate,   4'b0101,  "up: 0110 -> 0101");
        chk_val(position, 14'h0020, "cursor one-hot at bit 5");
        center;
        chk_val(user_sol, 14'h00A0, "center toggles bit 5");

        $display("\n--- en low gates out button activity ---");
        @(negedge clk); en = 1'b0;
        press(D);
        chk_val(gstate,   4'b0101,  "en low: cursor does not move");
        chk_val(position, 14'h0020, "en low: position unchanged");
        chk_val(user_sol, 14'h00A0, "en low: user_sol unchanged");

        $display("\n--- reset_pulse clears state while disabled ---");
        pulse_reset;
        chk_val(gstate,   4'b0000,  "reset_pulse clears cursor state");
        chk_val(position, 14'h0001, "reset_pulse -> cursor on bit 0");
        chk_val(user_sol, 14'h0000, "reset_pulse clears user_sol");

        // Re-enable: the machine still works.
        @(negedge clk); en = 1'b1;
        press(D);
        chk_val(gstate, 4'b0101, "still functional after reset_pulse");

        $display("\n--- asynchronous reset ---");
        #3 reset = 1'b1; #1;
        chk_val(gstate,   4'b0000,  "async reset -> cursor state 0");
        chk_val(user_sol, 14'h0000, "async reset clears user_sol");
        chk_val(position, 14'h0001, "async reset -> cursor bit 0");
        @(negedge clk); reset = 1'b0;

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
