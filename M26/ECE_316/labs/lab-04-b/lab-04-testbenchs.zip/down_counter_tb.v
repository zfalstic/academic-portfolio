`timescale 1ns / 1ps
//=============================================================================
// down_counter_tb.v  --  self-checking testbench for down_counter
//
// down_counter: async reset -> 0; synchronous load -> load_val; otherwise it
// decrements each clock while count != 0 and parks at 0.  done = (count == 0).
// In the real design load_val comes from T_LEVEL / T_GAME; here we drive it
// directly and use short loads so the whole run stays far under 1,000,000 ns.
//=============================================================================
module down_counter_tb;

    localparam integer CLK_PERIOD = 10;   // 100 MHz

    reg        clk, reset, load;
    reg  [9:0] load_val;
    wire [9:0] count;
    wire       done;

    integer errors, checks, k;

    down_counter uut (
        .clk      (clk),
        .reset    (reset),
        .load     (load),
        .load_val (load_val),
        .count    (count),
        .done     (done)
    );

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    task tick; begin @(posedge clk); #1; end endtask

    task chk_val;
        input [31:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %0d, expected %0d)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%0d)", $time, msg, actual);
        end
    endtask

    // Watchdog: full run is well under 100 us.
    initial begin
        #200_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        load = 1'b0; load_val = 10'd0; reset = 1'b1;

        $display("\n=== down_counter testbench ===");

        // ---- reset ----
        repeat (3) @(posedge clk);
        @(negedge clk); reset = 1'b0; #1;
        chk_val(count, 10'd0, "reset -> count == 0");
        chk_val(done,  1'b1,  "reset -> done asserted (count == 0)");

        // ---- load a small value, watch it count down ----
        @(negedge clk); load = 1'b1; load_val = 10'd5;
        @(posedge clk); #1;              // capture the load
        @(negedge clk); load = 1'b0;
        chk_val(count, 10'd5, "load -> count == load_val (5)");
        chk_val(done,  1'b0,  "loaded non-zero -> done deasserted");

        for (k = 4; k >= 0; k = k - 1) begin
            tick;
            chk_val(count, k[9:0], "count decrements toward zero");
        end
        chk_val(done, 1'b1, "count reached 0 -> done asserted");

        // ---- parks at 0 (no underflow) ----
        tick; tick;
        chk_val(count, 10'd0, "count stays parked at 0");
        chk_val(done,  1'b1,  "done stays asserted at 0");

        // ---- long load near the 10-bit max, verify full countdown ----
        @(negedge clk); load = 1'b1; load_val = 10'd1000;
        @(posedge clk); #1;
        @(negedge clk); load = 1'b0;
        chk_val(count, 10'd1000, "load -> count == 1000");
        for (k = 0; k < 1000; k = k + 1) tick;   // 1000 cycles ~ 10 us
        chk_val(count, 10'd0, "1000-count countdown reaches 0");
        chk_val(done,  1'b1,  "done asserted after full countdown");

        // ---- load has priority over decrement (reload mid-count) ----
        @(negedge clk); load = 1'b1; load_val = 10'd50;
        @(posedge clk); #1;
        @(negedge clk); load = 1'b0;
        tick; tick;                              // 50 -> 48
        chk_val(count, 10'd48, "counting down from a fresh load (48)");
        @(negedge clk); load = 1'b1; load_val = 10'd300;
        @(posedge clk); #1;
        @(negedge clk); load = 1'b0;
        chk_val(count, 10'd300, "mid-count reload overrides decrement");

        // ---- async reset while counting ----
        tick; tick;
        #3 reset = 1'b1;                         // asynchronous, off-edge
        #1;
        chk_val(count, 10'd0, "async reset clears count immediately");
        chk_val(done,  1'b1,  "async reset -> done asserted");
        @(negedge clk); reset = 1'b0;

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
