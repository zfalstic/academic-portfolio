`timescale 1ns / 1ps
//=============================================================================
// fsm_controller_tb.v  --  self-checking testbench for fsm_controller
//
// 4-state ring: IDLE(0) -> LEVEL(1) -> GAME(2) -> SCORE(3) -> IDLE.
// Each edge is taken only on its matching one-hot transition code; any other
// code holds the state.  pulse[k] is a combinational "entering state k" strobe.
// Driven directly off a 10 ns TB clock, so the run is a few hundred ns.
//=============================================================================
module fsm_controller_tb;

    localparam integer CLK_PERIOD = 10;
    localparam [1:0] S_IDLE=2'd0, S_LEVEL=2'd1, S_GAME=2'd2, S_SCORE=2'd3;

    reg         clk, reset;
    reg  [3:0]  transition;
    wire [1:0]  state;
    wire [3:0]  pulse;

    integer errors, checks;

    fsm_controller uut (
        .clk        (clk),
        .reset      (reset),
        .transition (transition),
        .state      (state),
        .pulse      (pulse)
    );

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    task chk_val;
        input [31:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %0b, expected %0b)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%0b)", $time, msg, actual);
        end
    endtask

    // Apply a transition code, check the combinational pulse this cycle, then
    // clock once and check the resulting state.
    task step;
        input [3:0]    tr;
        input [1:0]    exp_state;
        input [3:0]    exp_pulse;
        input [8*56:1] msg;
        begin
            @(negedge clk);
            transition = tr;
            #1;
            chk_val(pulse, exp_pulse, msg);      // "entering" strobe
            @(posedge clk); #1;
            chk_val(state, exp_state, msg);      // registered next-state
        end
    endtask

    initial begin
        #20_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        transition = 4'b0000; reset = 1'b1;

        $display("\n=== fsm_controller testbench ===");

        repeat (2) @(posedge clk);
        @(negedge clk); reset = 1'b0; #1;
        chk_val(state, S_IDLE, "reset -> IDLE");
        chk_val(pulse, 4'b0000, "reset -> no pulse");

        $display("\n--- wrong codes hold each state ---");
        step(4'b0000, S_IDLE, 4'b0000, "IDLE holds on 0000");
        step(4'b0010, S_IDLE, 4'b0000, "IDLE ignores LEVEL's code");
        step(4'b1000, S_IDLE, 4'b0000, "IDLE ignores SCORE's code");

        $display("\n--- full lap around the ring ---");
        step(4'b0001, S_LEVEL, 4'b0010, "IDLE -> LEVEL, pulse[1]");
        step(4'b0001, S_LEVEL, 4'b0000, "LEVEL ignores IDLE's code");
        step(4'b0010, S_GAME,  4'b0100, "LEVEL -> GAME, pulse[2]");
        step(4'b0100, S_GAME,  4'b0000, "GAME re-check: wrong code holds");
        step(4'b0100, S_SCORE, 4'b1000, "GAME -> SCORE, pulse[3]");
        step(4'b1000, S_IDLE,  4'b0001, "SCORE -> IDLE, pulse[0]");

        $display("\n--- second lap confirms it repeats ---");
        step(4'b0001, S_LEVEL, 4'b0010, "IDLE -> LEVEL again");
        step(4'b0010, S_GAME,  4'b0100, "LEVEL -> GAME again");

        $display("\n--- asynchronous reset from a non-zero state ---");
        #3 reset = 1'b1; #1;
        chk_val(state, S_IDLE, "async reset forces IDLE immediately");
        @(negedge clk); reset = 1'b0;
        step(4'b0001, S_LEVEL, 4'b0010, "FSM still advances after reset");

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
