`timescale 1ns / 1ps
//=============================================================================
// up_counter_tb.v  --  self-checking testbench for up_counter
//
// up_counter (16-bit): async reset -> 0.  Priority thereafter:
//     1) en & count != 0xFFFF   -> count + 1   (increment wins over reset_pulse)
//     2) reset_pulse            -> 0
// done = (count == 0xFFFF); the counter saturates at max.
//
// To observe done/saturation the counter must ramp all the way to 65535, so
// this bench uses a fast 6 ns TB clock: the full ramp takes ~0.39 ms, leaving
// the whole run comfortably under 1,000,000 ns.
//=============================================================================
module up_counter_tb;

    localparam integer CLK_PERIOD = 6;    // fast TB clock so the ramp fits budget
    localparam [15:0]  MAX = 16'hFFFF;

    reg         clk, reset, en, reset_pulse;
    wire [15:0] count;
    wire        done;

    integer errors, checks, k;

    up_counter uut (
        .clk         (clk),
        .reset       (reset),
        .en          (en),
        .reset_pulse (reset_pulse),
        .count       (count),
        .done        (done)
    );

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    task tick; begin @(posedge clk); #1; end endtask

    task chk_val;
        input [31:0]   actual, expected;
        input [8*56:1] msg;
        begin
            checks = checks + 1;
            if (actual !== expected) begin
                errors = errors + 1;
                $display("[%t] *** FAIL : %0s (got %0h, expected %0h)",
                         $time, msg, actual, expected);
            end else
                $display("[%t]     pass : %0s (%0h)", $time, msg, actual);
        end
    endtask

    // Watchdog: full ramp ~0.39 ms; give headroom but stay under 1 ms.
    initial begin
        #800_000;
        $display("*** WATCHDOG TIMEOUT ***");
        $finish;
    end

    initial begin
        $timeformat(-9, 1, " ns", 12);
        errors = 0; checks = 0;
        en = 1'b0; reset_pulse = 1'b0; reset = 1'b1;

        $display("\n=== up_counter testbench ===");

        // ---- reset ----
        repeat (3) @(posedge clk);
        @(negedge clk); reset = 1'b0; #1;
        chk_val(count, 16'd0, "reset -> count == 0");
        chk_val(done,  1'b0,  "reset -> done deasserted");

        // ---- enable: increments each clock ----
        @(negedge clk); en = 1'b1;
        tick; chk_val(count, 16'd1, "en -> count increments to 1");
        tick; chk_val(count, 16'd2, "en -> count increments to 2");
        tick; chk_val(count, 16'd3, "en -> count increments to 3");

        // ---- disable: holds ----
        @(negedge clk); en = 1'b0;
        tick; tick;
        chk_val(count, 16'd3, "en low -> count holds");

        // ---- reset_pulse with en low -> clears ----
        @(negedge clk); reset_pulse = 1'b1;
        @(posedge clk); #1;
        @(negedge clk); reset_pulse = 1'b0;
        chk_val(count, 16'd0, "reset_pulse (en low) clears count");

        // ---- increment has priority over reset_pulse ----
        @(negedge clk); en = 1'b1;
        tick; tick; tick;                          // count = 3
        chk_val(count, 16'd3, "count == 3 before priority test");
        @(negedge clk); reset_pulse = 1'b1;        // en still high, count < max
        tick;
        chk_val(count, 16'd4, "en+reset_pulse below max -> increment wins");
        @(negedge clk); reset_pulse = 1'b0;

        // ---- clear, then ramp all the way to saturation ----
        @(negedge clk); en = 1'b0; reset_pulse = 1'b1;
        @(posedge clk); #1;
        @(negedge clk); reset_pulse = 1'b0; en = 1'b1;
        chk_val(count, 16'd0, "cleared to 0 before ramp");

        k = 0;
        while ((done !== 1'b1) && (k < 70000)) begin
            tick; k = k + 1;
        end
        chk_val(count, MAX,  "ramp reaches 0xFFFF");
        chk_val(done,  1'b1, "done asserts at 0xFFFF");

        // ---- saturates at max ----
        tick; tick;
        chk_val(count, MAX,  "count saturates at 0xFFFF (no wrap)");
        chk_val(done,  1'b1, "done stays asserted at max");

        // ---- reset_pulse clears even at max (increment branch inactive) ----
        @(negedge clk); reset_pulse = 1'b1;        // en high, count == max
        @(posedge clk); #1;
        @(negedge clk); reset_pulse = 1'b0;
        chk_val(count, 16'd0, "reset_pulse at max clears to 0");
        chk_val(done,  1'b0,  "done deasserts after clear");

        $display("\n=== RESULT: %0s  (%0d/%0d checks) ===\n",
                 (errors==0) ? "PASS" : "FAIL", checks-errors, checks);
        $finish;
    end

endmodule
