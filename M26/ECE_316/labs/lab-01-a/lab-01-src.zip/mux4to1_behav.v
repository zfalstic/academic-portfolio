`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/11/2026 02:18:08 PM
// Design Name: 
// Module Name: mux4to1_behav
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux4to1_behav(
    input wire i0, i1, i2, i3, s0, s1,
    output wire d
);
    reg temp_d;
    assign d = temp_d;
    always @(*) begin
        case ({s1, s0})
            2'b00: temp_d = i0;
            2'b01: temp_d = i1;
            2'b10: temp_d = i2;
            2'b11: temp_d = i3;
        endcase
    end
endmodule
