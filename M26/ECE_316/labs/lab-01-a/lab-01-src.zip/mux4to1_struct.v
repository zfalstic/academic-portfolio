`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/11/2026 02:16:18 PM
// Design Name: 
// Module Name: mux4to1_struct
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux4to1_struct(
    input wire i0, i1, i2, i3, s0, s1,
    output wire d
);
    wire ns0, ns1;
    not (ns0, s0);
    not (ns1, s1);
    
    wire a0, a1, a2, a3;
    and (a0, i0, ns0, ns1);
    and (a1, i1, s0, ns1);
    and (a2, i2, ns0, s1);
    and (a3, i3, s0, s1);
    
    or (d, a0, a1, a2, a3);
endmodule
