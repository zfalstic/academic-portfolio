`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/14/2026 03:36:50 PM
// Design Name: 
// Module Name: mux4to1_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux4to1_tb;
    reg i0, i1, i2, i3, s0, s1;
    wire ds, db;

    mux4to1_struct uuts (
        .i0(i0), .i1(i1), .i2(i2), .i3(i3),
        .s0(s0), .s1(s1),
        .d(ds)
    );
    
    mux4to1_behav uutb (
        .i0(i0), .i1(i1), .i2(i2), .i3(i3),
        .s0(s0), .s1(s1),
        .d(db)
    );
    
    integer i, j;
    initial begin
        for (i = 0; i < 4; i = i + 1) begin
            {s1, s0} = i[1:0];
            for (j = 0; j < 16; j = j + 1) begin
                {i3, i2, i1, i0} = j[3:0];
                #10;
            end
        end
        $finish;
    end
endmodule
